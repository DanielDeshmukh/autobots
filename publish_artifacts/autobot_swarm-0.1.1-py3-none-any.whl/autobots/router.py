from __future__ import annotations

import json
import os
import re
import time
from dataclasses import dataclass
from typing import Callable

from dotenv import load_dotenv

from .catalog import ClusterCatalog, ModelSpec
from .executor import PhaseExecutor, WorkPacket
from .workspace import TargetProjectWorkspace


load_dotenv()


STATUS_PRIORITY = ("IN_PROGRESS", "PENDING")
STATUS_PATTERN = re.compile(r"\b(PENDING|IN_PROGRESS|COMPLETE)\b")
CHECKBOX_PATTERN = re.compile(r"\[( |x|~)\]")
PROGRESS_TRACKER_FILE = "progress-tracker.md"
PROTECTED_PROGRESS_FILES = {PROGRESS_TRACKER_FILE}
SECRETARY_SNIPPET_CLUSTERS = {"UltraMagnus", "Jazz"}
COORDINATION_LAWS = """Autobots Coordination Laws:
1. Use pessimistic locks for critical context files: architecture.md and security-auth.md.
2. Never write progress-tracker.md from a specialist, reviewer, or repair cluster.
3. A lightweight Optimus secretary model owns progress-tracker.md updates.
4. If a lock is stale for more than 60 seconds, reclaim it and continue.
5. Report task completion back to Optimus instead of editing shared progress state directly."""


@dataclass
class PhaseRecord:
    line_index: int
    raw_line: str
    title: str
    status: str


@dataclass
class ClusterMessage:
    speaker: str
    objective: str
    summary: str


@dataclass
class ClusterPlan:
    primary_cluster: str
    primary_lead: ModelSpec
    primary_reviewer: ModelSpec
    primary_support: list[ModelSpec]
    command_lead: ModelSpec
    command_reviewer: ModelSpec
    secretary_lead: ModelSpec
    safety_lead: ModelSpec
    repair_lead: ModelSpec


@dataclass
class ExecutionResult:
    cluster_name: str
    summary: str
    raw_response: str
    files_written: list[str]
    journal: list[ClusterMessage]
    plan: ClusterPlan


EventHandler = Callable[[str], None]


class ModelContractError(ValueError):
    pass


class AutobotRouter:
    def __init__(self, api_key: str | None = None, catalog: ClusterCatalog | None = None):
        self.api_key = api_key or os.getenv("NVIDIA_API_KEY")
        self.client = self._build_client() if self.api_key else None
        self.catalog = catalog or ClusterCatalog(api_key=self.api_key)
        self.executor = PhaseExecutor(api_key=self.api_key)

    def read_phase_documents(self, workspace: TargetProjectWorkspace) -> tuple[str, str]:
        roadmap = workspace.read_context_file("roadmap.md")
        progress = workspace.read_context_file("progress-tracker.md")
        return roadmap, progress

    def find_next_phase(self, progress_text: str) -> PhaseRecord | None:
        lines = progress_text.splitlines()
        parsed = [self._parse_phase_line(index, line) for index, line in enumerate(lines)]
        parsed = [phase for phase in parsed if phase is not None]

        for status in STATUS_PRIORITY:
            for phase in parsed:
                if phase.status == status:
                    return phase
        return None

    def mark_phase_complete(self, progress_text: str, phase: PhaseRecord) -> str:
        return self._update_phase_status(progress_text, phase, "COMPLETE")

    def _update_phase_status(self, progress_text: str, phase: PhaseRecord, status: str) -> str:
        lines = progress_text.splitlines()
        original = lines[phase.line_index]
        updated = STATUS_PATTERN.sub(status, original, count=1)

        if updated == original:
            checkbox = {"PENDING": "[ ]", "IN_PROGRESS": "[~]", "COMPLETE": "[x]"}[status]
            updated = CHECKBOX_PATTERN.sub(checkbox, original, count=1)
        if updated == original:
            updated = f"{original} {status}"

        lines[phase.line_index] = updated
        return "\n".join(lines) + ("\n" if progress_text.endswith("\n") else "")

    def build_cluster_plan(self, phase: PhaseRecord, roadmap_text: str) -> ClusterPlan:
        signal = f"{phase.title}\n{roadmap_text}"
        primary_cluster = self.catalog.route(signal)
        primary_lead, primary_reviewer, primary_support = self.catalog.select_models(primary_cluster, signal)
        command_lead, command_reviewer, _ = self.catalog.select_models("Optimus", signal)
        secretary_lead = self._select_secretary_model()
        safety_lead, _, _ = self.catalog.select_models("RedAlert", signal)
        repair_lead, _, _ = self.catalog.select_models("Ratchet", signal)
        return ClusterPlan(
            primary_cluster=primary_cluster,
            primary_lead=primary_lead,
            primary_reviewer=primary_reviewer,
            primary_support=primary_support,
            command_lead=command_lead,
            command_reviewer=command_reviewer,
            secretary_lead=secretary_lead,
            safety_lead=safety_lead,
            repair_lead=repair_lead,
        )

    def build_work_packet_from_phase(
        self,
        phase: PhaseRecord,
        roadmap_text: str,
    ) -> WorkPacket:
        """Extract phase information and build a structured work packet."""
        # Parse relevant information from the roadmap
        phase_id = self._extract_phase_id(phase.title)
        constraints = self._extract_constraints(roadmap_text, phase_id)
        validation_commands = self._extract_validation_commands(roadmap_text, phase_id)
        acceptance_checks = self._extract_acceptance_checks(roadmap_text, phase_id)
        relevant_paths = self._extract_relevant_paths(roadmap_text, phase_id)

        return WorkPacket(
            phase_id=phase_id,
            title=phase.title,
            goal=self._extract_phase_goal(roadmap_text, phase_id),
            relevant_files=relevant_paths,
            constraints=constraints,
            validation_commands=validation_commands,
            acceptance_checks=acceptance_checks,
        )

    def _extract_phase_id(self, title: str) -> str:
        """Extract phase ID (P1, P2, P3, etc.) from title."""
        match = re.search(r"\b(P\d+)\b", title)
        return match.group(1) if match else "P0"

    def _extract_phase_goal(self, roadmap_text: str, phase_id: str) -> str:
        """Extract the goal for a phase from roadmap."""
        pattern = rf"## {phase_id}.*?\n\n.*?(?=##|\Z)"
        match = re.search(pattern, roadmap_text, re.DOTALL | re.IGNORECASE)
        if match:
            text = match.group(0)
            lines = text.split("\n")
            for line in lines:
                if "goal:" in line.lower():
                    return line.split(":", 1)[1].strip()
        return f"Execute {phase_id}"

    def _extract_relevant_paths(self, roadmap_text: str, phase_id: str) -> list[str]:
        """Extract relevant file paths for a phase."""
        pattern = rf"## {phase_id}.*?[Rr]elevant\s+(?:paths|files):\s*(.+?)(?:\n\n|\Z)"
        match = re.search(pattern, roadmap_text, re.DOTALL)
        if match:
            paths_text = match.group(1).strip()
            paths = [p.strip() for p in re.split(r"[,;]", paths_text) if p.strip()]
            return paths[:20]  # Limit to first 20
        return []

    def _extract_validation_commands(self, roadmap_text: str, phase_id: str) -> list[str]:
        """Extract validation commands for a phase."""
        pattern = rf"## {phase_id}.*?[Vv]alidation.*?:\s*(.+?)(?:\n\n|\Z)"
        match = re.search(pattern, roadmap_text, re.DOTALL)
        if match:
            commands_text = match.group(1).strip()
            commands = [c.strip() for c in re.split(r"[,;]", commands_text) if c.strip()]
            return commands[:5]  # Limit to first 5
        return []

    def _extract_constraints(self, roadmap_text: str, phase_id: str) -> list[str]:
        """Extract constraints for a phase."""
        pattern = rf"## {phase_id}.*?[Cc]onstraints?:\s*(.+?)(?:\n\n|\Z)"
        match = re.search(pattern, roadmap_text, re.DOTALL)
        if match:
            constraints_text = match.group(1).strip()
            constraints = [c.strip() for c in re.split(r"[,;]", constraints_text) if c.strip()]
            return constraints[:5]
        return []

    def _extract_acceptance_checks(self, roadmap_text: str, phase_id: str) -> list[str]:
        """Extract acceptance checks for a phase."""
        pattern = rf"## {phase_id}.*?[Aa]ccept(?:ance)?.*?:\s*(.+?)(?:\n\n|\Z)"
        match = re.search(pattern, roadmap_text, re.DOTALL)
        if match:
            checks_text = match.group(1).strip()
            checks = [c.strip() for c in re.split(r"[,;]", checks_text) if c.strip()]
            return checks[:5]
        return []

    def execute_phase(
        self,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        roadmap_text: str,
        progress_text: str,
        event_handler: EventHandler | None = None,
    ) -> ExecutionResult:
        plan = self.build_cluster_plan(phase, roadmap_text)
        progress_text = self.begin_phase(workspace, phase, progress_text, plan, event_handler=event_handler)
        self._emit(
            event_handler,
            f"Optimus planning {phase.title} with {plan.command_lead.model_id}.",
        )
        self._emit(
            event_handler,
            f"Optimus routing '{phase.title}' to {plan.primary_cluster} with {plan.primary_lead.model_id}.",
        )
        command_payload, command_raw = self._run_command_stage(plan, phase, roadmap_text, progress_text)
        self._emit(
            event_handler,
            f"{plan.primary_cluster} working on {phase.title}.",
        )
        specialist_payload, specialist_raw = self._run_specialist_stage(
            plan,
            workspace,
            phase,
            roadmap_text,
            progress_text,
            command_payload,
            event_handler=event_handler,
        )
        self._emit(
            event_handler,
            f"{plan.primary_cluster} completed {phase.title} and updated status to Optimus.",
        )
        review_payload, review_raw = self._run_safety_stage(
            plan,
            phase,
            specialist_payload,
            command_payload,
        )
        self._emit(
            event_handler,
            f"RedAlert reviewed {phase.title}. Verdict: {(review_payload.get('status') or 'pass').upper()}",
        )

        raw_parts = [command_raw, specialist_raw, review_raw]
        journal = [
            ClusterMessage(
                speaker=f"Optimus/{plan.command_lead.model_id}",
                objective="Hierarchical planning",
                summary=(command_payload.get("summary") or "Created the execution brief.").strip(),
            ),
            ClusterMessage(
                speaker=f"{plan.primary_cluster}/{plan.primary_lead.model_id}",
                objective="Primary implementation",
                summary=(specialist_payload.get("summary") or "Generated files.").strip(),
            ),
            ClusterMessage(
                speaker=f"RedAlert/{plan.safety_lead.model_id}",
                objective="Safety and quality review",
                summary=(review_payload.get("summary") or "Reviewed generated output.").strip(),
            ),
        ]

        final_payload = specialist_payload
        final_lock_owner = f"{plan.primary_cluster}/{plan.primary_lead.model_id}"
        if (review_payload.get("status") or "").lower() == "revise":
            repair_payload, repair_raw = self._run_repair_stage(
                plan,
                workspace,
                phase,
                roadmap_text,
                progress_text,
                command_payload,
                specialist_payload,
                review_payload,
                event_handler=event_handler,
            )
            raw_parts.append(repair_raw)
            journal.append(
                ClusterMessage(
                    speaker=f"Ratchet/{plan.repair_lead.model_id}",
                    objective="Repair and refinement",
                    summary=(repair_payload.get("summary") or "Applied repairs after review.").strip(),
                )
            )
            self._emit(
                event_handler,
                f"Ratchet repaired {phase.title} and returned the update to Optimus.",
            )
            final_payload = repair_payload
            final_lock_owner = f"Ratchet/{plan.repair_lead.model_id}"

        safe_files = self._enforce_generated_file_laws(final_payload.get("files", []))
        files_written = self._persist_generated_files(
            workspace,
            safe_files,
            lock_owner=final_lock_owner,
            event_handler=event_handler,
        )
        summary = (final_payload.get("summary") or "Phase executed.").strip()
        return ExecutionResult(
            cluster_name=plan.primary_cluster,
            summary=summary,
            raw_response="\n\n".join(part for part in raw_parts if part),
            files_written=files_written,
            journal=journal,
            plan=plan,
        )

    def refine_with_ratchet(
        self,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        roadmap_text: str,
        progress_text: str,
        previous_result: ExecutionResult,
        feedback: str,
        event_handler: EventHandler | None = None,
    ) -> ExecutionResult:
        self._emit(
            event_handler,
            f"Ratchet revising {phase.title} with feedback from Optimus.",
        )
        repair_payload, repair_raw = self._run_repair_stage(
            previous_result.plan,
            workspace,
            phase,
            roadmap_text,
            progress_text,
            {"summary": previous_result.summary},
            {
                "summary": previous_result.summary,
                "files": self._file_entries_from_paths(previous_result.files_written, workspace),
            },
            {
                "status": "revise",
                "summary": feedback or "User requested another pass.",
                "issues": [feedback or "User requested another pass."],
            },
            event_handler=event_handler,
        )
        safe_files = self._enforce_generated_file_laws(repair_payload.get("files", []))
        files_written = self._persist_generated_files(
            workspace,
            safe_files,
            lock_owner=f"Ratchet/{previous_result.plan.repair_lead.model_id}",
            event_handler=event_handler,
        )
        journal = previous_result.journal + [
            ClusterMessage(
                speaker=f"Ratchet/{previous_result.plan.repair_lead.model_id}",
                objective="User-directed refinement",
                summary=(repair_payload.get("summary") or "Applied user feedback.").strip(),
            )
        ]
        self._emit(
            event_handler,
            f"Ratchet completed the revision for {phase.title} and returned it to Optimus.",
        )
        return ExecutionResult(
            cluster_name="Ratchet",
            summary=(repair_payload.get("summary") or "Phase refined.").strip(),
            raw_response=repair_raw,
            files_written=files_written,
            journal=journal,
            plan=previous_result.plan,
        )

    def begin_phase(
        self,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        progress_text: str,
        plan: ClusterPlan,
        *,
        event_handler: EventHandler | None = None,
    ) -> str:
        if phase.status == "IN_PROGRESS":
            return progress_text

        self._emit(
            event_handler,
            f"Optimus secretary {plan.secretary_lead.model_id} updating progress-tracker.md for {phase.title}.",
        )
        updated_progress = self._update_phase_status(progress_text, phase, "IN_PROGRESS")
        workspace.write_context_file(
            PROGRESS_TRACKER_FILE,
            updated_progress,
            lock_owner=f"Optimus/{plan.secretary_lead.model_id}",
        )
        return updated_progress

    def complete_phase(
        self,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        progress_text: str,
        plan: ClusterPlan,
        *,
        event_handler: EventHandler | None = None,
    ) -> str:
        self._emit(
            event_handler,
            f"Optimus secretary {plan.secretary_lead.model_id} updating progress-tracker.md to COMPLETE for {phase.title}.",
        )
        updated_progress = self._update_phase_status(progress_text, phase, "COMPLETE")
        workspace.write_context_file(
            PROGRESS_TRACKER_FILE,
            updated_progress,
            lock_owner=f"Optimus/{plan.secretary_lead.model_id}",
        )
        return updated_progress

    def _run_command_stage(
        self,
        plan: ClusterPlan,
        phase: PhaseRecord,
        roadmap_text: str,
        progress_text: str,
    ) -> tuple[dict, str]:
        prompt = f"""
You are the command tier of the Autobots swarm.
Use hierarchical reasoning to prepare a concise execution brief for the specialist cluster.
Treat the coordination rules below as hard laws.

{COORDINATION_LAWS}

Current phase:
{phase.raw_line}

Roadmap:
{roadmap_text}

Progress tracker:
{progress_text}

Selected primary cluster: {plan.primary_cluster}
Primary lead model: {plan.primary_lead.model_id}
Primary reviewer model: {plan.primary_reviewer.model_id}
Support models: {", ".join(model.model_id for model in plan.primary_support) or "None"}

Return strict JSON:
{{
  "summary": "one paragraph mission brief",
  "implementation_goals": ["goal 1", "goal 2"],
  "risks": ["risk 1"],
  "acceptance_checks": ["check 1", "check 2"]
}}
""".strip()
        raw = self._complete(plan.command_lead.model_id, prompt)
        payload = self._parse_json(raw)
        self.validate_command_payload(payload)
        return payload, raw

    def _run_specialist_stage(
        self,
        plan: ClusterPlan,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        roadmap_text: str,
        progress_text: str,
        command_payload: dict,
        event_handler: EventHandler | None = None,
    ) -> tuple[dict, str]:
        progress_context_label = "Progress tracker"
        progress_context = progress_text
        if plan.primary_cluster in SECRETARY_SNIPPET_CLUSTERS:
            progress_context_label = (
                f"Optimus secretary timeline snippet from {PROGRESS_TRACKER_FILE}"
            )
            progress_context = self._build_progress_tracker_snippet(phase, progress_text)
            self._emit(
                event_handler,
                f"Optimus secretary {plan.secretary_lead.model_id} injected a timeline snippet for {plan.primary_cluster}.",
            )

        prompt = f"""
You are the {plan.primary_cluster} implementation cluster.
The command tier and support models have already coordinated your mission.
Act as a collaborative cluster: the lead writes, the reviewer critiques, and support models fill gaps.
Treat the coordination rules below as hard laws.

{COORDINATION_LAWS}

Workspace constraints:
1. Write to appropriate project roots: src/, app/, lib/, tests/, docs/, scripts/, or context/.
2. Choose the root that matches the file type and project structure.
3. Never write in the Autobots engine repository itself.
4. Return full file contents, not diffs.
5. Never write `progress-tracker.md`; report progress back to Optimus instead.

Target roots available:
- src root: {workspace.src_root}
- app root: {workspace.target_root / "app"}
- lib root: {workspace.target_root / "lib"}
- tests root: {workspace.target_root / "tests"}
- docs root: {workspace.target_root / "docs"}
- scripts root: {workspace.target_root / "scripts"}
- context root: {workspace.context_root}

Phase:
{phase.raw_line}

Roadmap:
{roadmap_text}

{progress_context_label}:
{progress_context}

Execution brief:
{json.dumps(command_payload, indent=2)}

Cluster composition:
- Lead: {plan.primary_lead.model_id}
- Reviewer: {plan.primary_reviewer.model_id}
- Support: {", ".join(model.model_id for model in plan.primary_support) or "None"}

Return strict JSON:
{{
  "summary": "what the cluster changed",
  "implementation_notes": ["note 1", "note 2"],
  "files": [
    {{
      "root": "src",
      "path": "relative/path.ext",
      "content": "full file content"
    }}
  ]
}}
""".strip()
        raw = self._complete(plan.primary_lead.model_id, prompt)
        payload = self._parse_json(raw)
        if "files" not in payload:
            payload["files"] = []
        self.validate_specialist_payload(payload)
        return payload, raw

    def _run_safety_stage(
        self,
        plan: ClusterPlan,
        phase: PhaseRecord,
        specialist_payload: dict,
        command_payload: dict,
    ) -> tuple[dict, str]:
        prompt = f"""
You are Red Alert reviewing the specialist cluster output for correctness, safety, and maintainability.
Treat the coordination rules below as hard laws.

{COORDINATION_LAWS}

Phase:
{phase.raw_line}

Command brief:
{json.dumps(command_payload, indent=2)}

Specialist output:
{json.dumps(specialist_payload, indent=2)}

Return strict JSON:
{{
  "status": "pass" or "revise",
  "summary": "review verdict",
  "issues": ["issue 1", "issue 2"]
}}
""".strip()
        raw = self._complete(plan.safety_lead.model_id, prompt)
        payload = self._parse_json(raw)
        payload.setdefault("issues", [])
        payload.setdefault("status", "pass")
        self.validate_review_payload(payload)
        return payload, raw

    def _run_repair_stage(
        self,
        plan: ClusterPlan,
        workspace: TargetProjectWorkspace,
        phase: PhaseRecord,
        roadmap_text: str,
        progress_text: str,
        command_payload: dict,
        specialist_payload: dict,
        review_payload: dict,
        event_handler: EventHandler | None = None,
    ) -> tuple[dict, str]:
        prompt = f"""
You are Ratchet, the repair cluster.
Revise the implementation after autonomous review and feedback from the swarm.
Treat the coordination rules below as hard laws.

{COORDINATION_LAWS}

Workspace constraints:
1. Write to appropriate project roots: src/, app/, lib/, tests/, docs/, scripts/, or context/.
2. Choose the root that matches the file type and project structure.
3. Never write in the Autobots engine repository itself.
4. Return full file contents, not diffs.
5. Never write `progress-tracker.md`; report progress back to Optimus instead.

Target roots available:
- src root: {workspace.src_root}
- app root: {workspace.target_root / "app"}
- lib root: {workspace.target_root / "lib"}
- tests root: {workspace.target_root / "tests"}
- docs root: {workspace.target_root / "docs"}
- scripts root: {workspace.target_root / "scripts"}
- context root: {workspace.context_root}

Phase:
{phase.raw_line}

Roadmap:
{roadmap_text}

Progress tracker:
{progress_text}

Command brief:
{json.dumps(command_payload, indent=2)}

Previous implementation:
{json.dumps(specialist_payload, indent=2)}

Repair instructions:
{json.dumps(review_payload, indent=2)}

Return strict JSON:
{{
  "summary": "what Ratchet improved",
  "files": [
    {{
      "root": "src",
      "path": "relative/path.ext",
      "content": "full file content"
    }}
  ]
}}
""".strip()
        raw = self._complete(plan.repair_lead.model_id, prompt)
        payload = self._parse_json(raw)
        if "files" not in payload:
            payload["files"] = []
        self.validate_repair_payload(payload)
        return payload, raw

    def _complete(self, model_id: str, prompt: str) -> str:
        if self.client is None:
            raise RuntimeError("NVIDIA_API_KEY is missing. Cannot execute the swarm.")

        response = self.client.chat.completions.create(
            model=model_id,
            messages=[
                {
                    "role": "system",
                    "content": (
                        "You are part of a hierarchical Autobots coding swarm. "
                        "Autobots Coordination Laws are mandatory. "
                        "Never write progress-tracker.md unless you are the Optimus secretary. "
                        "Use pessimistic locks for architecture.md and security-auth.md with a 60 second stale-lock reclaim rule. "
                        "Reply with strict JSON only."
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            temperature=0.2,
            max_tokens=4096,
        )
        return response.choices[0].message.content or ""

    def _build_client(self):
        from openai import OpenAI

        return OpenAI(
            base_url="https://integrate.api.nvidia.com/v1",
            api_key=self.api_key,
        )

    def _select_secretary_model(self) -> ModelSpec:
        optimus = self.catalog.get_cluster("Optimus")
        for model in optimus.models:
            if model.model_id.lower().endswith("step-3.5-flash"):
                return model
        return optimus.models[0]

    def _build_progress_tracker_snippet(self, phase: PhaseRecord, progress_text: str) -> str:
        lines = progress_text.splitlines()
        if not lines:
            return phase.raw_line

        start = max(0, phase.line_index - 2)
        end = min(len(lines), phase.line_index + 3)
        snippet_lines: list[str] = []
        for index in range(start, end):
            prefix = ">>" if index == phase.line_index else "  "
            snippet_lines.append(f"{prefix} line {index + 1}: {lines[index]}")
        return "\n".join(snippet_lines)

    def run_validation_commands(
        self,
        workspace: TargetProjectWorkspace,
        work_packet: WorkPacket,
        event_handler: EventHandler | None = None,
    ) -> tuple[bool, str]:
        """Run validation commands for a work packet using the execution engine."""
        if not work_packet.validation_commands:
            return True, "No validation commands specified."

        all_passed, results = self.executor.validate_phase(workspace, work_packet, event_handler=event_handler)
        validation_report = self.executor.format_validation_results(results)
        return all_passed, validation_report

    def _enforce_generated_file_laws(self, files: list[dict]) -> list[dict]:
        safe_files: list[dict] = []
        for file_spec in files:
            root_name = (file_spec.get("root") or "src").strip().lower()
            relative_path = (file_spec.get("path") or "").strip().replace("\\", "/")
            if root_name == "context" and relative_path in PROTECTED_PROGRESS_FILES:
                continue
            safe_files.append(file_spec)
        return safe_files

    def _persist_generated_files(
        self,
        workspace: TargetProjectWorkspace,
        files: list[dict],
        *,
        lock_owner: str,
        event_handler: EventHandler | None = None,
    ) -> list[str]:
        attempts = workspace.LOCK_RETRY_ATTEMPTS
        delay = workspace.LOCK_RETRY_DELAY_SECONDS

        for attempt in range(1, attempts + 1):
            try:
                return workspace.apply_generated_files(files, lock_owner=lock_owner)
            except Exception as exc:
                if not self._is_lock_collision_error(exc):
                    raise
                if not self._files_include_critical_context(files):
                    raise
                if attempt >= attempts:
                    raise
                self._emit(
                    event_handler,
                    f"{lock_owner} waiting on a critical file lock. Sleep/retry {attempt}/{attempts - 1}.",
                )
                time.sleep(delay)

        return []

    def _files_include_critical_context(self, files: list[dict]) -> bool:
        for file_spec in files:
            root_name = (file_spec.get("root") or "src").strip().lower()
            relative_path = (file_spec.get("path") or "").strip().replace("\\", "/")
            if root_name == "context" and relative_path in TargetProjectWorkspace.CRITICAL_CONTEXT_FILES:
                return True
        return False

    def _is_lock_collision_error(self, exc: Exception) -> bool:
        return "Context lock for" in str(exc)

    def _emit(self, event_handler: EventHandler | None, message: str) -> None:
        if event_handler is not None:
            event_handler(message)

    def _parse_phase_line(self, index: int, line: str) -> PhaseRecord | None:
        status_match = STATUS_PATTERN.search(line)
        if status_match:
            status = status_match.group(1)
            title = STATUS_PATTERN.sub("", line, count=1)
            title = self._clean_phase_title(title)
            return PhaseRecord(index, line, title or f"Phase {index + 1}", status)

        checkbox_match = CHECKBOX_PATTERN.search(line)
        if checkbox_match:
            marker = checkbox_match.group(0)
            status = {"[ ]": "PENDING", "[~]": "IN_PROGRESS", "[x]": "COMPLETE"}.get(
                marker
            )
            title = self._clean_phase_title(CHECKBOX_PATTERN.sub("", line, count=1))
            return PhaseRecord(index, line, title or f"Phase {index + 1}", status)

        return None

    def _clean_phase_title(self, raw_title: str) -> str:
        cleaned = raw_title.strip()
        cleaned = cleaned.strip("|")
        parts = [part.strip() for part in cleaned.split("|") if part.strip()]
        if parts:
            cleaned = " | ".join(parts)
        cleaned = re.sub(r"^[\-\*\d\.\)\s#:]+", "", cleaned)
        return cleaned.strip()

    def _parse_json(self, raw_content: str) -> dict:
        candidate = raw_content.strip()
        fenced_match = re.search(r"```(?:json)?\s*(\{.*\})\s*```", candidate, re.DOTALL)
        if fenced_match:
            candidate = fenced_match.group(1)

        payload = json.loads(candidate)
        if not isinstance(payload, dict):
            raise ValueError("Model response must be a JSON object.")
        return payload

    def validate_command_payload(self, payload: dict) -> None:
        self._require_string(payload, "summary", "command payload")
        self._require_string_list(payload, "implementation_goals", "command payload")
        self._require_string_list(payload, "risks", "command payload")
        self._require_string_list(payload, "acceptance_checks", "command payload")

    def validate_specialist_payload(self, payload: dict) -> None:
        self._require_string(payload, "summary", "specialist payload")
        self._require_string_list(payload, "implementation_notes", "specialist payload")
        self._require_file_list(payload, "specialist payload")

    def validate_review_payload(self, payload: dict) -> None:
        status = self._require_string(payload, "status", "review payload").lower()
        if status not in {"pass", "revise"}:
            raise ModelContractError(
                f"review payload field 'status' must be 'pass' or 'revise', got '{payload.get('status')}'."
            )
        self._require_string(payload, "summary", "review payload")
        self._require_string_list(payload, "issues", "review payload")

    def validate_repair_payload(self, payload: dict) -> None:
        self._require_string(payload, "summary", "repair payload")
        self._require_file_list(payload, "repair payload")

    def _require_string(self, payload: dict, field: str, payload_name: str) -> str:
        value = payload.get(field)
        if not isinstance(value, str) or not value.strip():
            raise ModelContractError(
                f"{payload_name} field '{field}' must be a non-empty string."
            )
        return value

    def _require_string_list(self, payload: dict, field: str, payload_name: str) -> list[str]:
        value = payload.get(field)
        if not isinstance(value, list) or any(not isinstance(item, str) for item in value):
            raise ModelContractError(
                f"{payload_name} field '{field}' must be a list of strings."
            )
        return value

    def _require_file_list(self, payload: dict, payload_name: str) -> list[dict]:
        files = payload.get("files")
        if not isinstance(files, list):
            raise ModelContractError(f"{payload_name} field 'files' must be a list.")

        for index, file_spec in enumerate(files):
            if not isinstance(file_spec, dict):
                raise ModelContractError(
                    f"{payload_name} files[{index}] must be an object."
                )
            root_name = file_spec.get("root")
            relative_path = file_spec.get("path")
            content = file_spec.get("content")
            if root_name not in {"src", "context"}:
                raise ModelContractError(
                    f"{payload_name} files[{index}].root must be 'src' or 'context'."
                )
            if not isinstance(relative_path, str) or not relative_path.strip():
                raise ModelContractError(
                    f"{payload_name} files[{index}].path must be a non-empty string."
                )
            if not isinstance(content, str):
                raise ModelContractError(
                    f"{payload_name} files[{index}].content must be a string."
                )
        return files

    def _file_entries_from_paths(
        self,
        file_paths: list[str],
        workspace: TargetProjectWorkspace,
    ) -> list[dict]:
        entries: list[dict] = []
        for file_path in file_paths:
            path = os.path.abspath(file_path)
            if path.startswith(str(workspace.src_root)):
                root = "src"
                relative = os.path.relpath(path, workspace.src_root)
            elif path.startswith(str(workspace.context_root)):
                root = "context"
                relative = os.path.relpath(path, workspace.context_root)
            else:
                continue
            entries.append(
                {
                    "root": root,
                    "path": relative.replace("\\", "/"),
                    "content": open(path, encoding="utf-8").read(),
                }
            )
        return entries
